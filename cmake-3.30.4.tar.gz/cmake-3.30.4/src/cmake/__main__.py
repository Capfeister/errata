from cmake import cmake

if __name__ == "__main__":
    cmake()
