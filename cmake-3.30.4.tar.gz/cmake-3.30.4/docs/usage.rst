=====
Usage
=====

After :doc:`installing </installation>` the package using `pip`, the executables
``cmake``, ``cpack`` and ``ctest`` will be available in the ``PATH`` and can be
used to configure and build any projects.
