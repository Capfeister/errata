Testimonials
============

Glyph Lefkowitz
~~~~~~~~~~~~~~~

Frankly, Hyper-h2 is almost SURREAL in how well-factored and decoupled the implementation is from I/O.  If libraries in the Python ecosystem looked like this generally, Twisted would be a much better platform than it is.  (Frankly, most of Twisted's _own_ protocol implementations should aspire to such cleanliness.)

(`Source <https://twistedmatrix.com/pipermail/twisted-python/2015-November/029894.html>`_)
