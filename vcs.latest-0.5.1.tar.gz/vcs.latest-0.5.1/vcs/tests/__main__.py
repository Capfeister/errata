from __init__ import * # allows to run tests with: python vcs/tests

if __name__ == '__main__':
    main()
